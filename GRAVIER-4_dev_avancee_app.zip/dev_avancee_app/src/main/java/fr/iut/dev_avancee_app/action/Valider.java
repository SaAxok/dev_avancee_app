package fr.iut.dev_avancee_app.action;

import java.io.IOException;

import fr.iut.dev_avancee_app.Action;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Valider")
public class Valider implements Action {

    @Override
    public String perform(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String attribut2 = request.getParameter("attribut2");
        String attribut3 = request.getParameter("attribut3");

        if (attribut2 == null || attribut3 == null || attribut2.isEmpty() || attribut3.isEmpty()) {
            return "valider.jsp";
        } else {
            return "home.jsp";
        }
    }
}

