package fr.iut.dev_avancee_app.controller;

import fr.iut.dev_avancee_app.Action;
import fr.iut.dev_avancee_app.factory.MyFactory;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class AppController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pathAction = request.getServletPath().substring(1);

        Action action = MyFactory.getAction(pathAction);
        assert action != null;
        String suite = action.perform(request, response);
        response.sendRedirect(suite);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {
        String pathAction = request.getServletPath().substring(1);

        Action action = MyFactory.getAction(pathAction);
        assert action != null;
        String suite = action.perform(request, response);
        response.sendRedirect(suite);
    }

}
