package fr.iut.dev_avancee_app.factory;

import fr.iut.dev_avancee_app.Action;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MyFactory {
    private static Map<String, Class<? extends Action>> actions = new HashMap<>();

    static {
        try {
            InputStream xml = MyFactory.class.getClassLoader().getResourceAsStream("actions.xml");

            if (xml == null) throw new RuntimeException("actions.xml non trouvé");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xml);
            NodeList nList = doc.getElementsByTagName("action");

            for (int i = 0; i < nList.getLength(); i++) {
                Element elem = (Element) nList.item(i);
                String path = elem.getAttribute("path");
                String className = elem.getAttribute("class");
                Class<?> clazz = Class.forName(className);
                if (Action.class.isAssignableFrom(clazz)) {
                    actions.put(path, (Class<? extends Action>) clazz);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Action getAction(String pathAction) {
        Class<? extends Action> actionClass = actions.get(pathAction);
        if (actionClass != null) {
            try {
                return actionClass.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}