package fr.iut.dev_avancee_app.action;

import java.io.IOException;

import fr.iut.dev_avancee_app.Action;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/home")
public class Home implements Action {

    @Override
    public String perform(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            return "login.jsp";
        }

        String username = (String) session.getAttribute("user");
        String attribut2 = (String) session.getAttribute("attribut2");
        String attribut3 = (String) session.getAttribute("attribut3");

        request.setAttribute("attribut2", attribut2);
        request.setAttribute("attribut3", attribut3);
        request.setAttribute("username", username);

        return "home.jsp";
    }
}



