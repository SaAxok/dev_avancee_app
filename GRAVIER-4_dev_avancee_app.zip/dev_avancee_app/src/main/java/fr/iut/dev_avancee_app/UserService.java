package fr.iut.dev_avancee_app;

import java.util.HashMap;
import java.util.Map;

public class UserService {
    private static final Map<String, String> users = new HashMap<>();

    static {
        users.put("admin", "password123");
        users.put("user", "123456");
    }

    public static boolean authenticate(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }
}
