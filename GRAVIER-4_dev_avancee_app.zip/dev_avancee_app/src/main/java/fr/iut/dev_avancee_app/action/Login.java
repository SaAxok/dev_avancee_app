package fr.iut.dev_avancee_app.action;

import java.io.IOException;

import fr.iut.dev_avancee_app.Action;
import fr.iut.dev_avancee_app.UserService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class Login implements Action {

    @Override
    public String perform(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (UserService.authenticate(username, password)) {
            HttpSession session = request.getSession();
            session.setAttribute("user", username);
            return "home.jsp";
        } else {
            return "error.jsp";
        }
    }
}


