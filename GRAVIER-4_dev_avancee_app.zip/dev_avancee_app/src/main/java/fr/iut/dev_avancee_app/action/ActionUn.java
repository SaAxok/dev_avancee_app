package fr.iut.dev_avancee_app.action;

import java.io.IOException;

import fr.iut.dev_avancee_app.Action;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ActionUn")
public class
ActionUn implements Action {

    @Override
    public String perform(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String attribut2 = request.getParameter("attribut2");
        String attribut3 = request.getParameter("attribut3");

        request.getSession().setAttribute("attribut2", attribut2);
        request.getSession().setAttribute("attribut3", attribut3);

       return "home.jsp";
    }
}

